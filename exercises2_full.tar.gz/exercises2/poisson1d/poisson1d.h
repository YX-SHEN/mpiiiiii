#define maxn 64+2

/* #include "gfunc.h" */


