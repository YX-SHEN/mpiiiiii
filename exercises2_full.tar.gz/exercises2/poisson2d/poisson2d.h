#ifndef POISSON2D_H
#define POISSON2D_H

#define maxn (64 + 2)  

#endif
